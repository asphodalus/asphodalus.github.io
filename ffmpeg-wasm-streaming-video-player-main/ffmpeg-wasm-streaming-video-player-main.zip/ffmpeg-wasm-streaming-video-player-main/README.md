# ffmpeg-wasm-streaming-video-player

An example of using FFmpeg.wasm to perform streaming transcoding within the browser
